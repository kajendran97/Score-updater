
public class player {
	public int playerNum;
	public String playerName;
	public int playerAge;
	public int playerDistance;
	public int playerCoins;
	public int playerScore;
	
	public player(int num, String name, int age, int distance, int coins ,int score){
		
		playerNum = num;
		playerName = name;
		playerAge = age;
		playerDistance = distance;
		playerCoins = coins;
		playerScore = score;
	}
}
